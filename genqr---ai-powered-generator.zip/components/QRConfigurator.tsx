import React, { useState, useEffect } from 'react';
import { QRType, QRConfig, WifiData, EmailData, VCardData, DotType, CornerSquareType, CornerDotType } from '../types';
import { Link, Type, Wifi, Mail, Contact, Palette, Settings2, Info, LayoutGrid, Image as ImageIcon, Circle } from 'lucide-react';

interface QRConfiguratorProps {
  onUpdate: (config: QRConfig) => void;
}

const QRConfigurator: React.FC<QRConfiguratorProps> = ({ onUpdate }) => {
  const [activeType, setActiveType] = useState<QRType>(QRType.URL);
  
  // Specific Data States
  const [url, setUrl] = useState('https://example.com');
  const [text, setText] = useState('Hello World');
  const [wifi, setWifi] = useState<WifiData>({ ssid: '', password: '', encryption: 'WPA', hidden: false });
  const [email, setEmail] = useState<EmailData>({ email: '', subject: '', body: '' });
  const [vcard, setVcard] = useState<VCardData>({ firstName: '', lastName: '', phone: '', email: '', org: '', title: '', url: '' });

  // Appearance
  const [fgColor, setFgColor] = useState('#000000');
  const [bgColor, setBgColor] = useState('#ffffff');
  const [level, setLevel] = useState<'L'|'M'|'Q'|'H'>('M');
  
  // Advanced Styles
  const [dotType, setDotType] = useState<DotType>('square');
  const [cornerSquareType, setCornerSquareType] = useState<CornerSquareType>('square');
  const [cornerDotType, setCornerDotType] = useState<CornerDotType>('square');
  const [logoUrl, setLogoUrl] = useState<string>('');

  // Build the QR string based on standard schemas
  useEffect(() => {
    let value = '';
    switch (activeType) {
      case QRType.URL:
        value = url;
        break;
      case QRType.TEXT:
        value = text;
        break;
      case QRType.WIFI:
        value = `WIFI:T:${wifi.encryption};S:${wifi.ssid};P:${wifi.password};H:${wifi.hidden};;`;
        break;
      case QRType.EMAIL:
        value = `mailto:${email.email}?subject=${encodeURIComponent(email.subject)}&body=${encodeURIComponent(email.body)}`;
        break;
      case QRType.VCARD:
        value = `BEGIN:VCARD\nVERSION:3.0\nN:${vcard.lastName};${vcard.firstName}\nFN:${vcard.firstName} ${vcard.lastName}\nORG:${vcard.org}\nTITLE:${vcard.title}\nTEL:${vcard.phone}\nEMAIL:${vcard.email}\nURL:${vcard.url}\nEND:VCARD`;
        break;
    }

    onUpdate({
      type: activeType,
      value: value || ' ', // fallback to avoid empty qr errors
      fgColor,
      bgColor,
      level,
      dotType,
      cornerSquareType,
      cornerDotType,
      logoUrl
    });
  }, [activeType, url, text, wifi, email, vcard, fgColor, bgColor, level, dotType, cornerSquareType, cornerDotType, logoUrl, onUpdate]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (ev) => {
            if (ev.target?.result) {
                setLogoUrl(ev.target.result as string);
            }
        };
        reader.readAsDataURL(file);
    }
  };

  const tabs = [
    { type: QRType.URL, icon: Link, label: 'URL' },
    { type: QRType.TEXT, icon: Type, label: 'Text' },
    { type: QRType.WIFI, icon: Wifi, label: 'WiFi' },
    { type: QRType.EMAIL, icon: Mail, label: 'Email' },
    { type: QRType.VCARD, icon: Contact, label: 'VCard' },
  ];

  const getLevelDescription = (l: string) => {
    switch(l) {
        case 'L': return 'Low (~7% recovery). Best for large datasets.';
        case 'M': return 'Medium (~15% recovery). Standard for most uses.';
        case 'Q': return 'Quartile (~25% recovery). Good for industrial use.';
        case 'H': return 'High (~30% recovery). Best for artistic/logo use.';
        default: return '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Type Selection */}
      <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-sm overflow-x-auto">
        <div className="flex space-x-1 min-w-max">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeType === tab.type;
            return (
              <button
                key={tab.type}
                onClick={() => setActiveType(tab.type)}
                className={`flex items-center space-x-2 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                  isActive 
                    ? 'bg-indigo-50 text-indigo-700 shadow-sm' 
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon size={18} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Input Forms */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 border-b border-slate-100 pb-3">Content</h3>
        
        {activeType === QRType.URL && (
          <div className="space-y-3">
            <label className="block text-sm font-medium text-slate-700">Website URL</label>
            <input 
              type="url" 
              value={url} 
              onChange={(e) => setUrl(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none"
              placeholder="https://www.example.com" 
            />
          </div>
        )}

        {activeType === QRType.TEXT && (
          <div className="space-y-3">
             <label className="block text-sm font-medium text-slate-700">Plain Text</label>
             <textarea 
               value={text} 
               onChange={(e) => setText(e.target.value)}
               rows={4}
               className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none"
               placeholder="Enter your text here..." 
             />
          </div>
        )}

        {activeType === QRType.WIFI && (
          <div className="space-y-4">
             <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Network Name (SSID)</label>
                <input type="text" value={wifi.ssid} onChange={(e) => setWifi({...wifi, ssid: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
             </div>
             <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
                <input type="text" value={wifi.password} onChange={(e) => setWifi({...wifi, password: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
             </div>
             <div className="flex space-x-4">
                <div className="flex-1">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Encryption</label>
                    <select value={wifi.encryption} onChange={(e) => setWifi({...wifi, encryption: e.target.value as any})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="WPA">WPA/WPA2</option>
                        <option value="WEP">WEP</option>
                        <option value="nopass">None</option>
                    </select>
                </div>
                <div className="flex items-center pt-6">
                    <label className="flex items-center space-x-2 text-sm text-slate-700 cursor-pointer">
                        <input type="checkbox" checked={wifi.hidden} onChange={(e) => setWifi({...wifi, hidden: e.target.checked})} className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500" />
                        <span>Hidden Network</span>
                    </label>
                </div>
             </div>
          </div>
        )}

        {activeType === QRType.EMAIL && (
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email To</label>
                    <input type="email" value={email.email} onChange={(e) => setEmail({...email, email: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Subject</label>
                    <input type="text" value={email.subject} onChange={(e) => setEmail({...email, subject: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Message Body</label>
                    <textarea value={email.body} onChange={(e) => setEmail({...email, body: e.target.value})} rows={3} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
            </div>
        )}

        {activeType === QRType.VCARD && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">First Name</label>
                    <input type="text" value={vcard.firstName} onChange={(e) => setVcard({...vcard, firstName: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Last Name</label>
                    <input type="text" value={vcard.lastName} onChange={(e) => setVcard({...vcard, lastName: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone</label>
                    <input type="tel" value={vcard.phone} onChange={(e) => setVcard({...vcard, phone: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                    <input type="email" value={vcard.email} onChange={(e) => setVcard({...vcard, email: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Company</label>
                    <input type="text" value={vcard.org} onChange={(e) => setVcard({...vcard, org: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Job Title</label>
                    <input type="text" value={vcard.title} onChange={(e) => setVcard({...vcard, title: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Website</label>
                    <input type="url" value={vcard.url} onChange={(e) => setVcard({...vcard, url: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
            </div>
        )}
      </div>

      {/* Design Configuration */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 border-b border-slate-100 pb-3 flex items-center">
            <Palette size={20} className="mr-2 text-indigo-600" /> Design
        </h3>
        
        <div className="grid grid-cols-1 gap-6">
            {/* Logo Upload */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <label className="block text-sm font-medium text-slate-700 mb-3 flex items-center">
                    <ImageIcon size={16} className="mr-2" /> Logo
                </label>
                <div className="flex items-center space-x-4">
                     <div className="shrink-0 w-16 h-16 bg-white border border-slate-200 rounded-lg flex items-center justify-center overflow-hidden">
                        {logoUrl ? <img src={logoUrl} alt="Logo" className="w-full h-full object-contain" /> : <ImageIcon className="text-slate-300" />}
                     </div>
                     <div className="flex-1">
                        <input 
                            type="file" 
                            accept="image/*"
                            onChange={handleLogoUpload}
                            className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 transition-all"
                        />
                        {logoUrl && (
                            <button onClick={() => setLogoUrl('')} className="mt-2 text-xs text-red-500 hover:text-red-600 font-medium">Remove Logo</button>
                        )}
                     </div>
                </div>
            </div>

            {/* Colors */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Foreground</label>
                    <div className="flex items-center space-x-3">
                        <input type="color" value={fgColor} onChange={(e) => setFgColor(e.target.value)} className="h-10 w-full rounded border border-slate-300 cursor-pointer" />
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Background</label>
                    <div className="flex items-center space-x-3">
                        <input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} className="h-10 w-full rounded border border-slate-300 cursor-pointer" />
                    </div>
                </div>
            </div>

            {/* Pattern Style */}
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center">
                    <LayoutGrid size={16} className="mr-2" /> Pattern Style
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {['square', 'dots', 'rounded', 'classy', 'classy-rounded', 'extra-rounded'].map((t) => (
                        <button
                            key={t}
                            onClick={() => setDotType(t as any)}
                            className={`px-1 py-2 text-xs rounded-md border transition-all ${
                                dotType === t
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                            }`}
                        >
                            {t.replace('-', ' ')}
                        </button>
                    ))}
                </div>
            </div>

            {/* Corner Style */}
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                     <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center">
                        <Circle size={16} className="mr-2" /> Corner Border
                    </label>
                    <div className="flex space-x-2">
                        {['square', 'extra-rounded', 'dot'].map((t) => (
                            <button
                                key={t}
                                onClick={() => setCornerSquareType(t as any)}
                                className={`flex-1 py-2 text-xs rounded-md border transition-all ${
                                    cornerSquareType === t
                                    ? 'bg-indigo-600 text-white border-indigo-600'
                                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                                }`}
                            >
                                {t.replace('-', ' ')}
                            </button>
                        ))}
                    </div>
                </div>
                 <div>
                     <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center">
                        <Circle size={12} className="mr-2 ml-1" /> Corner Center
                    </label>
                    <div className="flex space-x-2">
                        {['square', 'dot'].map((t) => (
                            <button
                                key={t}
                                onClick={() => setCornerDotType(t as any)}
                                className={`flex-1 py-2 text-xs rounded-md border transition-all ${
                                    cornerDotType === t
                                    ? 'bg-indigo-600 text-white border-indigo-600'
                                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                                }`}
                            >
                                {t}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Error Level */}
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center">
                    <Settings2 size={16} className="mr-1" /> Error Correction
                </label>
                <div className="grid grid-cols-4 gap-3 mb-3">
                    {[
                        { id: 'L', label: 'Low', sub: '7%' },
                        { id: 'M', label: 'Medium', sub: '15%' },
                        { id: 'Q', label: 'Quartile', sub: '25%' },
                        { id: 'H', label: 'High', sub: '30%' }
                    ].map((item) => (
                        <button
                            key={item.id}
                            onClick={() => setLevel(item.id as any)}
                            className={`flex flex-col items-center justify-center py-2.5 px-1 rounded-lg border transition-all ${
                                level === item.id
                                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                            }`}
                        >
                            <span className="font-bold text-sm mb-0.5">{item.id}</span>
                            <span className="text-[10px] opacity-90">{item.sub}</span>
                        </button>
                    ))}
                </div>
                 <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 flex items-start space-x-2">
                    <Info size={16} className="text-indigo-500 mt-0.5 shrink-0" />
                    <p className="text-xs text-slate-600 leading-relaxed">
                        <span className="font-semibold text-slate-800">Current Level ({level}):</span> {getLevelDescription(level)}
                    </p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default QRConfigurator;