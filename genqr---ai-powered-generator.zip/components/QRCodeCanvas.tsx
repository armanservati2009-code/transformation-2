import React, { useRef, useEffect } from 'react';
import { QRConfig } from '../types';
import { Download } from 'lucide-react';

interface QRCodeCanvasProps {
  config: QRConfig;
}

const QRCodeCanvas: React.FC<QRCodeCanvasProps> = ({ config }) => {
  const ref = useRef<HTMLDivElement>(null);
  const qrCode = useRef<any>(null);

  useEffect(() => {
    // Initialize QRCodeStyling only once
    if (typeof window.QRCodeStyling !== 'undefined') {
        qrCode.current = new window.QRCodeStyling({
            width: 300,
            height: 300,
            type: "svg", // Render as SVG for better crispness
            imageOptions: {
                crossOrigin: "anonymous",
                margin: 5
            }
        });
        if (ref.current) {
            ref.current.innerHTML = '';
            qrCode.current.append(ref.current);
        }
    }
  }, []);

  useEffect(() => {
    if (!qrCode.current) return;
    
    // Update the QR code when config changes
    qrCode.current.update({
        data: config.value,
        image: config.logoUrl || "",
        dotsOptions: {
            color: config.fgColor,
            type: config.dotType
        },
        backgroundOptions: {
            color: config.bgColor,
        },
        cornersSquareOptions: {
            type: config.cornerSquareType,
            color: config.fgColor
        },
        cornersDotOptions: {
            type: config.cornerDotType,
            color: config.fgColor
        },
        qrOptions: {
            errorCorrectionLevel: config.level
        }
    });
  }, [config]);

  const handleDownload = (extension: 'png' | 'jpeg' | 'svg') => {
    if (!qrCode.current) return;
    qrCode.current.download({
        name: "genqr-code",
        extension: extension
    });
  };

  return (
    <div className="flex flex-col items-center justify-center space-y-6 p-6 bg-white rounded-2xl shadow-sm border border-slate-200">
      <div className="p-4 bg-white rounded-lg shadow-inner border border-slate-100 flex justify-center items-center min-h-[300px]" ref={ref}>
        {/* QR Code will be appended here */}
      </div>
      
      <div className="flex space-x-2 w-full">
        <button
          onClick={() => handleDownload('png')}
          className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors font-medium text-sm"
        >
          <Download size={14} />
          <span>PNG</span>
        </button>
        <button
          onClick={() => handleDownload('jpeg')}
          className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg transition-colors font-medium text-sm"
        >
          <Download size={14} />
          <span>JPG</span>
        </button>
         <button
          onClick={() => handleDownload('svg')}
          className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg transition-colors font-medium text-sm"
        >
          <Download size={14} />
          <span>SVG</span>
        </button>
      </div>
    </div>
  );
};

export default QRCodeCanvas;