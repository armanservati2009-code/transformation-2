import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { ChatMessage } from '../types';

let chatSession: Chat | null = null;

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing from environment variables.");
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const initializeChat = async (): Promise<void> => {
  try {
    const ai = getAiClient();
    chatSession = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: `You are a helpful assistant integrated into a QR Code Generator app called GenQR. 
        Your goal is to help users generate content for their QR codes (e.g., writing a professional email body, formatting a VCard, or explaining how QR codes work).
        Keep responses concise and helpful. formatting is allowed using Markdown.
        If a user asks about QR code types, explain the difference between static and dynamic (though this app generates static ones currently).`,
      },
    });
  } catch (error) {
    console.error("Failed to initialize chat session:", error);
  }
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
  if (!chatSession) {
    await initializeChat();
  }

  if (!chatSession) {
    return "Sorry, I couldn't connect to the AI service. Please check your internet connection or API Key.";
  }

  try {
    const response: GenerateContentResponse = await chatSession.sendMessage({ message });
    return response.text || "I didn't get a response.";
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    return "Sorry, something went wrong while processing your request.";
  }
};
